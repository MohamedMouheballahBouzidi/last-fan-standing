
# Last Fan Standing - Evaluation Report

Generated: 2026-03-19 11:45:50

## Data Summary
- Total matches: 2581
- Seasons: 2019-20, 2020-21, 2021-22, 2022-23, 2023-24, 2024-25, 2025-26
- Training seasons: 2019-20, 2020-21, 2021-22, 2022-23, 2023-24, 2025-26
- Test seasons: 2024-25

## Win Probability Model (XGBoost)
- Log Loss: 0.2702
- Accuracy: 0.9077
- Average Brier Score: 0.0475

## Score Prediction Model (Poisson)
- MAE Home Goals: 1.030
- MAE Away Goals: 0.927
- RMSE Home Goals: 1.278
- RMSE Away Goals: 1.183

## Simulation Results (Greedy Strategy)
- Full Season Survival: 0.00%
- Average Weeks Survived: 2.0

## Top Features
               feature  importance
5           elo_prob_a    0.057608
3           elo_prob_h    0.055765
4           elo_prob_d    0.039949
2             elo_diff    0.031515
24     home_win_rate_3    0.023936
38     away_win_rate_3    0.017766
100     diff_points_10    0.016930
95   away_red_cards_10    0.014062
35    away_red_cards_3    0.012571
1             away_elo    0.012414

## Current Elo Rankings (Top 10)
                      team          elo
17                 Arsenal  1787.667259
3          Manchester City  1730.832091
18       Manchester United  1638.964699
19                 Chelsea  1631.001960
0                Liverpool  1624.674186
13             Aston Villa  1587.295155
11  Brighton & Hove Albion  1576.186208
23               Brentford  1575.219966
16        Newcastle United  1567.831049
4          AFC Bournemouth  1563.826048
