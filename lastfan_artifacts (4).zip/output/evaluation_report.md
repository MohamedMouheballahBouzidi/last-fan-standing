
# Last Fan Standing - Evaluation Report

Generated: 2026-03-20 00:01:32

## Data Summary
- Total matches: 2581
- Seasons: 2019-20, 2020-21, 2021-22, 2022-23, 2023-24, 2024-25, 2025-26
- Training seasons: 2019-20, 2020-21, 2021-22, 2022-23, 2023-24, 2025-26
- Test seasons: 2024-25

## Win Probability Model (XGBoost)
- Log Loss: 0.2311
- Accuracy: 0.9208
- Average Brier Score: 0.0413

## Score Prediction Model (Poisson)
- MAE Home Goals: 1.030
- MAE Away Goals: 0.927
- RMSE Home Goals: 1.278
- RMSE Away Goals: 1.183

## Simulation Results (Greedy Strategy)
- Full Season Survival: 0.00%
- Average Weeks Survived: 2.0

## Top Features
             feature  importance
3         elo_prob_h    0.094622
5         elo_prob_a    0.094151
4         elo_prob_d    0.064617
2           elo_diff    0.052650
56     market_prob_h    0.025311
55    diff_points_10    0.018800
53  away_win_rate_10    0.018335
57     market_prob_d    0.016966
0           home_elo    0.016382
1           away_elo    0.016001

## Current Elo Rankings (Top 10)
                      team          elo
17                 Arsenal  1787.667259
3          Manchester City  1730.832091
18       Manchester United  1638.964699
19                 Chelsea  1631.001960
0                Liverpool  1624.674186
13             Aston Villa  1587.295155
11  Brighton & Hove Albion  1576.186208
23               Brentford  1575.219966
16        Newcastle United  1567.831049
4          AFC Bournemouth  1563.826048
