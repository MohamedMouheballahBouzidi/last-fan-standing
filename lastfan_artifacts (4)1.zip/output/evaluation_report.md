
# Last Fan Standing - Evaluation Report

Generated: 2026-03-19 17:16:10

## Data Summary
- Total matches: 2581
- Seasons: 2019-20, 2020-21, 2021-22, 2022-23, 2023-24, 2024-25, 2025-26
- Training seasons: 2019-20, 2020-21, 2021-22, 2022-23, 2023-24, 2025-26
- Test seasons: 2024-25

## Win Probability Model (XGBoost)
- Log Loss: 1.0750
- Accuracy: 0.5224
- Average Brier Score: 0.1966

## Score Prediction Model (Poisson)
- MAE Home Goals: 1.030
- MAE Away Goals: 0.927
- RMSE Home Goals: 1.278
- RMSE Away Goals: 1.183

## Simulation Results (Greedy Strategy)
- Full Season Survival: 0.00%
- Average Weeks Survived: 2.0

## Top Features
                         feature  importance
101                market_prob_h    0.038523
103                market_prob_a    0.021023
3                     elo_prob_h    0.020465
5                     elo_prob_a    0.015634
21              home_red_cards_3    0.014030
24               home_win_rate_3    0.012757
102                market_prob_d    0.011540
98              away_win_rate_10    0.010754
2                       elo_diff    0.010727
20   home_defensive_volatility_3    0.010313

## Current Elo Rankings (Top 10)
                      team          elo
17                 Arsenal  1787.667259
3          Manchester City  1730.832091
18       Manchester United  1638.964699
19                 Chelsea  1631.001960
0                Liverpool  1624.674186
13             Aston Villa  1587.295155
11  Brighton & Hove Albion  1576.186208
23               Brentford  1575.219966
16        Newcastle United  1567.831049
4          AFC Bournemouth  1563.826048
